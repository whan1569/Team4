import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Camera, CameraType } from 'react-native-camera-kit';
import { request, PERMISSIONS, RESULTS } from 'react-native-permissions';

const MyApp = () => {
  const [hasPermission, setHasPermission] = useState(false);
  const [deviceReady, setDeviceReady] = useState(false);
  const cameraRef = useRef(null);

  // 카메라 권한 요청
  useEffect(() => {
    const checkCameraPermission = async () => {
      console.log('카메라 권한 요청 중...');
      const permissionStatus = await request(PERMISSIONS.ANDROID.CAMERA);
      if (permissionStatus === RESULTS.GRANTED) {
        console.log('카메라 권한 허용됨');
        setHasPermission(true);
        setDeviceReady(true);  // 권한 허용되면 바로 deviceReady를 true로 설정
      } else {
        console.log('카메라 권한 거부됨');
      }
    };
    checkCameraPermission();
  }, []);

  // 카메라가 로딩되면 호출되는 콜백 함수
  const handleCameraReady = () => {
    console.log('카메라가 준비되었습니다!');
    setDeviceReady(true);  // 카메라가 준비되면 deviceReady를 true로 설정
  };

  // deviceReady 상태 변경을 확인
  useEffect(() => {
    console.log('현재 deviceReady 상태:', deviceReady);
  }, [deviceReady]);

  return (
    <View style={styles.container}>
      <Text>
        {deviceReady ? '카메라가 준비되었습니다!' : '카메라 장치 로딩 중...'}
      </Text>
      {hasPermission && (
        <Camera
          ref={cameraRef}
          style={styles.camera}
          cameraType={CameraType.Back}
          onCameraReady={handleCameraReady} // 카메라가 준비되었을 때 호출될 함수
          captureAudio={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  camera: {
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
});

export default MyApp;
